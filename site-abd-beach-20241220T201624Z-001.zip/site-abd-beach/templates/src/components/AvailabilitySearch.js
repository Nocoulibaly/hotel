// AvailabilitySearch.js
import { Card, CardHeader, CardTitle, CardContent } from './ui/card.js';

const AvailabilitySearch = () => {
  const [message, setMessage] = React.useState('');
  const [rooms, setRooms] = React.useState([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const searchParams = new URLSearchParams(window.location.search);
    const checkIn = searchParams.get('check_in_date');
    const checkOut = searchParams.get('check_out_date');
    const numGuests = searchParams.get('num_guests');

    if (checkIn && checkOut) {
      fetch(`/api/availability?check_in_date=${checkIn}&check_out_date=${checkOut}&num_guests=${numGuests}`)
        .then(response => response.json())
        .then(data => {
          setRooms(data.rooms || []);
          if (data.rooms && data.rooms.length === 0) {
            setMessage('Aucune chambre disponible pour les dates sélectionnées.');
          }
        })
        .catch(err => {
          setMessage('Une erreur est survenue lors de la recherche.');
          console.error('Erreur:', err);
        })
        .finally(() => {
          setLoading(false);
        });
    } else {
      setLoading(false);
    }
  }, []);

  if (loading) {
    return <div className="text-center p-4">Chargement...</div>;
  }

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-6 text-center">Chambres Disponibles</h1>
      {message && (
        <div className="mb-6 p-4 text-center bg-amber-100 border border-amber-400 text-amber-700 rounded">
          {message}
        </div>
      )}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {rooms.map(room => (
          <Card key={room.id}>
            <CardHeader>
              <CardTitle>{`Chambre ${room.name}`}</CardTitle>
              <p className="text-gray-600">{`Type: ${room.max_occupancy}`}</p>
            </CardHeader>
            <CardContent>
              <img
                src={room.image || "/api/placeholder/400/300"}
                alt={`Chambre ${room.name}`}
                className="w-full h-48 object-cover rounded-t-lg"
              />
              <button className="mt-4 bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition">
                Réserver
              </button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default AvailabilitySearch;