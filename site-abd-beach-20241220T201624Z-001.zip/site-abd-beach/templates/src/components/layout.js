const Header = () => {
    return (
      <header className="bg-white shadow-md fixed w-full z-10">
        <div className="container mx-auto px-6 py-3 flex justify-between items-center">
          <div className="flex items-center">
            <span className="text-4xl font-bold logo-text text-orange-500">ABD</span>
            <span className="ml-2 text-2xl font-semibold text-gray-800">ABOUDIA BEACH</span>
          </div>
          <nav className="hidden md:flex contenu space-x-8">
            <a href="../templates/index.html" className="nav-link text-gray-800 hover:text-orange-500">Accueil</a>
            <a href="" className="nav-link text-gray-800 hover:text-orange-500">Chambres</a>
            <a href="#" className="nav-link text-gray-800 hover:text-orange-500">Restaurant</a>
            <a href="#" className="nav-link text-gray-800 hover:text-orange-500">Événements</a>
            <a href="#" className="nav-link text-gray-800 hover:text-orange-500">Contact</a>
            <button id="darkModeToggle" className="focus:outline-none">
              <i className="fas fa-moon text-gray-800"></i>
            </button>
            <a href="../templates/login.html" className="login-icon" title="Se connecter">
              <i className="fas fa-user-circle"></i>
            </a>
          </nav>
        </div>
      </header>
    );
};
  
const Footer = () => {
    return (
      <footer className="bg-gray-800 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-semibold mb-4">ABOUDIA BEACH</h3>
              <p>Votre paradis tropical sur la côte ivoirienne.</p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Liens rapides</h4>
              <ul>
                <li><a href="#" className="hover:text-orange-500">Accueil</a></li>
                <li><a href="#" className="hover:text-orange-500">Chambres</a></li>
                <li><a href="#" className="hover:text-orange-500">Restaurant</a></li>
                <li><a href="#" className="hover:text-orange-500">Spa</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Contact</h4>
              <p>123 Plage d'Aboudia</p>
              <p>Abidjan, Côte d'Ivoire</p>
              <p>Tél: +225 12 34 56 78</p>
              <p>Email: info@aboudiabeach.com</p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Suivez-nous</h4>
              <div className="flex space-x-4">
                <a href="#" className="text-2xl hover:text-orange-500"><i className="fab fa-facebook"></i></a>
                <a href="#" className="text-2xl hover:text-orange-500"><i className="fab fa-instagram"></i></a>
                <a href="#" className="text-2xl hover:text-orange-500"><i className="fab fa-twitter"></i></a>
                <a href="#" className="text-2xl hover:text-orange-500"><i className="fab fa-linkedin"></i></a>
              </div>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-700 text-center">
            <p>&copy; 2023 ABOUDIA BEACH. Tous droits réservés.</p>
          </div>
        </div>
      </footer>
    );
};
  
export { Header, Footer };