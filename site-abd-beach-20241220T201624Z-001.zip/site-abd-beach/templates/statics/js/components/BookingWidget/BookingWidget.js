// js/BookingWidget.js
import React from 'react';
import { useBookingForm } from './hooks/useBookingForm';
import { useBookingAPI } from './hooks/useBookingAPI';

const BookingWidget = () => {
  const {
    formData,
    validation,
    handleInputChange,
    validateDates
  } = useBookingForm();

  const {
    isLoading,
    error,
    checkAvailability
  } = useBookingAPI();

  const handleSubmit = async (event) => {
    event.preventDefault();
    
    if (!validateDates()) {
      return;
    }

    try {
      const result = await checkAvailability(formData);
      
      if (result.isAvailable && result.rooms.length > 0) {
        const params = new URLSearchParams({
          check_in_date: formData.checkIn,
          check_out_date: formData.checkOut,
          num_guests: formData.guests
        });
        window.location.href = `../templates/disponibilite.html?${params}`;
      } else {
        alert("Aucune chambre disponible pour ces dates.");
      }
    } catch (err) {
      console.error('Erreur:', err);
    }
  };

  return (
    <section id="dispoForm" className="py-16 bg-orange-500">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-semibold text-center text-white mb-8">
          Réservez Votre Séjour
        </h2>
        <form className="max-w-3xl mx-auto bg-white p-8 rounded-lg shadow-lg" onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            <div>
              <label className="block text-gray-700 mb-2" htmlFor="check-in">
                Date d'arrivée
              </label>
              <input
                type="date"
                id="check-in"
                value={formData.checkIn}
                onChange={(e) => handleInputChange('checkIn', e.target.value)}
                className={`w-full px-3 py-2 border rounded ${!validation.checkIn ? 'border-red-500' : ''}`}
              />
              {!validation.checkIn && (
                <p className="text-red-500 text-sm mt-1">
                  La date d'arrivée doit être aujourd'hui ou après
                </p>
              )}
            </div>
            <div>
              <label className="block text-gray-700 mb-2" htmlFor="check-out">
                Date de départ
              </label>
              <input
                type="date"
                id="check-out"
                value={formData.checkOut}
                onChange={(e) => handleInputChange('checkOut', e.target.value)}
                className={`w-full px-3 py-2 border rounded ${!validation.checkOut ? 'border-red-500' : ''}`}
              />
              {!validation.checkOut && (
                <p className="text-red-500 text-sm mt-1">
                  La date de départ doit être après la date d'arrivée
                </p>
              )}
            </div>
            <div>
              <label className="block text-gray-700 mb-2" htmlFor="guests">
                Nombre de personnes
              </label>
              <select
                id="guests"
                value={formData.guests}
                onChange={(e) => handleInputChange('guests', e.target.value)}
                className="w-full px-3 py-2 border rounded"
              >
                {[1, 2, 3, 4].map(num => (
                  <option key={num} value={num}>{num}</option>
                ))}
              </select>
            </div>
          </div>
          {error && (
            <p className="text-red-500 text-sm mt-4">{error}</p>
          )}
          <button
            type="submit"
            disabled={isLoading}
            className="btn-orange w-full mt-6 py-3 rounded text-lg font-semibold"
          >
            {isLoading ? 'Vérification...' : 'Vérifier la disponibilité'}
          </button>
        </form>
      </div>
    </section>
  );
};

export default BookingWidget;