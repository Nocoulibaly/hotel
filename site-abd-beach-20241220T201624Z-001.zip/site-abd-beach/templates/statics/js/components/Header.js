import React, { useContext } from 'react';
import { UserContext } from '../../context/UserContext';

const Header = () => {
  const { user } = useContext(UserContext);

  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="text-2xl font-bold text-orange-500">Hotel Logo</div>
          <nav className="hidden md:flex space-x-6">
            <a href="#" className="text-gray-600 hover:text-orange-500">Accueil</a>
            <a href="#rooms" className="text-gray-600 hover:text-orange-500">Chambres</a>
            <a href="#features" className="text-gray-600 hover:text-orange-500">Services</a>
            <a href="#contact" className="text-gray-600 hover:text-orange-500">Contact</a>
          </nav>
          <div>
            {user ? (
              <div className="flex items-center space-x-4">
                <span className="text-gray-600">Bonjour, {user.name}</span>
                <button className="btn-orange px-4 py-2 rounded">Mon Compte</button>
              </div>
            ) : (
              <button className="btn-orange px-4 py-2 rounded">Connexion</button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;