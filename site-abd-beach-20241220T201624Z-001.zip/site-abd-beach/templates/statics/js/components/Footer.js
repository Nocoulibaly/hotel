// js/Footer.js
import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-semibold mb-4">Notre Hôtel</h3>
            <ul className="space-y-2">
              <li><a href="#" className="hover:text-orange-500">À propos</a></li>
              <li><a href="#" className="hover:text-orange-500">Carrières</a></li>
              <li><a href="#" className="hover:text-orange-500">Actualités</a></li>
            </ul>
          </div>
          <div>
            <h3 className="text-xl font-semibold mb-4">Services</h3>
            <ul className="space-y-2">
              <li><a href="#" className="hover:text-orange-500">Restaurant</a></li>
              <li><a href="#" className="hover:text-orange-500">Spa</a></li>
              <li><a href="#" className="hover:text-orange-500">Fitness</a></li>
            </ul>
          </div>
          <div>
            <h3 className="text-xl font-semibold mb-4">Contact</h3>
            <ul className="space-y-2">
              <li>123 Rue de l'Hôtel</li>
              <li>75000 Paris</li>
              <li>Tél : 01 23 45 67 89</li>
              <li>Email : contact@hotel.com</li>
            </ul>
          </div>
          <div>
            <h3 className="text-xl font-semibold mb-4">Newsletter</h3>
            <form className="space-y-4">
              <input
                type="email"
                placeholder="Votre email"
                className="w-full px-4 py-2 rounded bg-gray-700 text-white"
              />
              <button className="btn-orange px-6 py-2 rounded w-full">
                S'abonner
              </button>
            </form>
          </div>
        </div>
        <div className="border-t border-gray-700 mt-8 pt-8 text-center">
          <p>&copy; 2024 Notre Hôtel. Tous droits réservés.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;