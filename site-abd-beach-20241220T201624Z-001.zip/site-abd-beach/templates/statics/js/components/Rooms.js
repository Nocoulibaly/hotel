// js/Rooms.js
import React from 'react';

const Rooms = () => {
  const rooms = [
    {
      title: "Chambre Standard",
      image: "/room1.jpg",
      price: "100€",
      description: "Parfaite pour les voyageurs solo ou en couple"
    },
    {
      title: "Suite Junior",
      image: "/room2.jpg",
      price: "200€",
      description: "Espace et confort pour un séjour prolongé"
    },
    {
      title: "Suite Exécutive",
      image: "/room3.jpg",
      price: "300€",
      description: "Le summum du luxe et du raffinement"
    }
  ];

  return (
    <section id="rooms" className="py-16">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-semibold text-center mb-12">Nos Chambres</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {rooms.map((room, index) => (
            <div key={index} className="bg-white rounded-lg shadow-lg overflow-hidden">
              <img
                src={room.image}
                alt={room.title}
                className="w-full h-64 object-cover"
              />
              <div className="p-6">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-xl font-semibold">{room.title}</h3>
                  <span className="text-orange-500 font-bold">{room.price}</span>
                </div>
                <p className="text-gray-600 mb-4">{room.description}</p>
                <button className="btn-orange w-full py-2 rounded">
                  Réserver
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Rooms;