// Theme Toggle
const themeToggle = document.getElementById('theme-toggle');
themeToggle.addEventListener('change', () => {
    document.body.classList.toggle('dark-mode');
});

// Gestionnaire du menu profil
const profileTrigger = document.getElementById('profileTrigger');
const profileMenu = document.getElementById('profileMenu');

// Toggle du menu profil
profileTrigger.addEventListener('click', (e) => {
e.stopPropagation();
profileMenu.classList.toggle('active');
});

// Fermer le menu si on clique en dehors
document.addEventListener('click', (e) => {
if (!profileMenu.contains(e.target) && !profileTrigger.contains(e.target)) {
profileMenu.classList.remove('active');
}
});

// Gestion de la déconnexion
document.querySelector('.logout').addEventListener('click', (e) => {
e.preventDefault();
// Ajoutez ici votre logique de déconnexion
alert('Déconnexion en cours...');
// Redirection vers la page de connexion par exemple
// window.location.href = 'login.html';
});
// Charts
const occupancyCtx = document.getElementById('occupancyChart').getContext('2d');
const roomTypeCtx = document.getElementById('roomTypeChart').getContext('2d');

// Occupancy Chart
new Chart(occupancyCtx, {
    type: 'line',
    data: {
        labels: ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'],
        datasets: [{
            label: 'Taux d\'occupation',
            data: [75, 82, 80, 85, 90, 95, 88],
            borderColor: '#009ffd',
            tension: 0.4,
            fill: true,
            backgroundColor: 'rgba(0, 159, 253, 0.1)'
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                position: 'top',
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                max: 100
            }
        }
    }
});

// Room Type Chart
new Chart(roomTypeCtx, {
    type: 'doughnut',
    data: {
        labels: ['Standard', 'Supérieure', 'Deluxe', 'Suite'],
        datasets: [{
            data: [30, 25, 15, 10],
            backgroundColor: [
                '#FF6384',
                '#36A2EB',
                '#FFCE56',
                '#4BC0C0'
            ]
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                position: 'bottom',
            }
        }
    }
});

// Animation pour les cartes
const cards = document.querySelectorAll('.card');
cards.forEach((card, index) => {
    card.style.animationDelay = `${index * 0.1}s`;
});

// Fonction de recherche
const searchInput = document.querySelector('.search-bar input');
searchInput.addEventListener('input', (e) => {
    const searchTerm = e.target.value.toLowerCase();
    // Implémentez ici la logique de recherche
});

// Simulation de données en temps réel
setInterval(() => {
    const randomValue = Math.floor(Math.random() * 10) + 70;
    occupancyChart.data.datasets[0].data.shift();
    occupancyChart.data.datasets[0].data.push(randomValue);
    occupancyChart.update();
}, 5000);

// Gestion des notifications
function showNotification(message) {
    // Implémentez ici la logique des notifications
}

// Responsive sidebar toggle
const sidebar = document.querySelector('.sidebar');
const mainContent = document.querySelector('.main-content');

function toggleSidebar() {
    sidebar.classList.toggle('collapsed');
    mainContent.classList.toggle('expanded');
}

// Gestion du responsive
function handleResize() {
    if (window.innerWidth <= 768) {
        sidebar.classList.add('collapsed');
        mainContent.classList.add('expanded');
    } else {
        sidebar.classList.remove('collapsed');
        mainContent.classList.remove('expanded');
    }
}

window.addEventListener('resize', handleResize);
handleResize();

// Animation de chargement
window.addEventListener('load', () => {
    document.body.classList.add('loaded');
});