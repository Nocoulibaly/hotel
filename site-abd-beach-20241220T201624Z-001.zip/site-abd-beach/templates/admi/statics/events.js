// Données de test
let eventTypes = [
    {
        id: 1,
        name: "Mariage",
        description: "Cérémonie et réception de mariage",
        basePrice: 500000,
        createdAt: new Date()
    },
    {
        id: 2,
        name: "Conférence",
        description: "Événement professionnel",
        basePrice: 1000,
        createdAt: new Date()
    }
];

let eventSpaces = [
    {
        id: 1,
        name: "Grande Salle",
        location: "Rez-de-chaussée",
        capacityMin: 50,
        capacityMax: 200,
        squareMeters: 300,
        basePrice: 2000,
        description: "Grande salle polyvalente",
        status: "available"
    },
    {
        id: 2,
        name: "Salle de Conférence",
        location: "1er étage",
        capacityMin: 20,
        capacityMax: 100,
        squareMeters: 150,
        basePrice: 1000,
        description: "Salle équipée pour conférences",
        status: "available"
    }
];

let eventQuotes = [
    {
        id: 1,
        userId: 1,
        eventTypeId: 1,
        eventSpaceId: 1,
        expectedGuests: 150,
        eventDate: "2024-12-15",
        startTime: "14:00",
        endTime: "23:00",
        description: "Mariage d'été",
        specialRequirements: "DJ et traiteur nécessaires",
        budgetRange: "2500-5000",
        status: "pending",
        createdAt: new Date(),
        updatedAt: new Date(),
        eventType: eventTypes[0],
        eventSpace: eventSpaces[0]
    }
];

// Fonctions utilitaires
function formatDate(dateStr) {
    return new Date(dateStr).toLocaleDateString('fr-FR');
}

function formatTime(timeStr) {
    return timeStr.substring(0, 5);
}

// Gestion de l'affichage
function renderQuotes(quotesToShow) {
    const grid = document.getElementById('quotesGrid');
    grid.innerHTML = quotesToShow.map(quote => `
        <div class="card">
            <div class="card-header">
                <h3>Demande #${quote.id}</h3>
                <span class="status-badge status-${quote.status}">
                    ${quote.status === "confirmed" ? "Confirmé" :
                      quote.status === "pending" ? "En attente" : "Annulé"}
                </span>
            </div>
            <div class="info-group">
                <strong>Type:</strong> ${quote.eventType.name}
            </div>
            <div class="info-group">
                <strong>Espace:</strong> ${quote.eventSpace.name}
            </div>
            <div class="info-group">
                <strong>Date:</strong> ${formatDate(quote.eventDate)}
            </div>
            <div class="info-group">
                <strong>Horaires:</strong> ${formatTime(quote.startTime)} - ${formatTime(quote.endTime)}
            </div>
            <div class="info-group">
                <strong>Invités:</strong> ${quote.expectedGuests}
            </div>
            <div class="info-group">
                <strong>Budget:</strong> ${quote.budgetRange} Fcfa
            </div>
            <div class="info-group">
                <strong>Description:</strong>
                <p>${quote.description}</p>
            </div>
        </div>
    `).join('');
}

function renderSpaces(spacesToShow) {
    const grid = document.getElementById('spacesGrid');
    grid.innerHTML = spacesToShow.map(space => `
        <div class="card">
            <div class="card-header">
                <h3>${space.name}</h3>
                <span class="price-tag">${space.basePrice}Fcfa</span>
            </div>
            <div class="info-group">
                <strong>Localisation:</strong> ${space.location}
            </div>
            <div class="info-group">
                <strong>Capacité:</strong> ${space.capacityMin} - ${space.capacityMax} personnes
            </div>
            <div class="info-group">
                <strong>Surface:</strong> ${space.squareMeters}m²
            </div>
            <div class="info-group">
                <strong>Description:</strong>
                <p>${space.description}</p>
            </div>
        </div>
    `).join('');
}

function renderEventTypes(typesToShow) {
const grid = document.getElementById('typesGrid');
grid.innerHTML = typesToShow.map(type => `
<div class="card">
    <div class="card-header">
        <h3>${type.name}</h3>
        <span class="price-tag">${type.basePrice}Fcfa</span>
    </div>
    <div class="info-group">
        <strong>Description:</strong>
        <p>${type.description}</p>
    </div>
    <div class="info-group">
        <strong>Créé le:</strong>
        <p>${formatDate(type.createdAt)}</p>
    </div>
</div>
`).join('');
}

// Gestion des filtres
function applyFilters() {
const date = document.getElementById('filterDate').value;
const eventType = document.getElementById('filterEventType').value;
const space = document.getElementById('filterSpace').value;
const status = document.getElementById('filterStatus').value;

const filtered = eventQuotes.filter(quote => {
if (date && quote.eventDate !== date) return false;
if (eventType !== 'all' && quote.eventTypeId !== parseInt(eventType)) return false;
if (space !== 'all' && quote.eventSpaceId !== parseInt(space)) return false;
if (status !== 'all' && quote.status !== status) return false;
return true;
});

renderQuotes(filtered);
}

// Gestion des onglets
function switchTab(tabName) {
// Mise à jour des classes actives
document.querySelectorAll('.tab').forEach(tab => {
tab.classList.remove('active');
});
event.target.classList.add('active');

// Masquer tous les contenus
document.getElementById('quotesGrid').style.display = 'none';
document.getElementById('spacesGrid').style.display = 'none';
document.getElementById('typesGrid').style.display = 'none';
document.getElementById('quotesFilters').style.display = 'none';

// Afficher le contenu approprié
switch(tabName) {
case 'quotes':
    document.getElementById('quotesGrid').style.display = 'grid';
    document.getElementById('quotesFilters').style.display = 'grid';
    renderQuotes(eventQuotes);
    break;
case 'spaces':
    document.getElementById('spacesGrid').style.display = 'grid';
    renderSpaces(eventSpaces);
    break;
case 'types':
    document.getElementById('typesGrid').style.display = 'grid';
    renderEventTypes(eventTypes);
    break;
}
}

// Gestion des modaux
function openQuoteModal() {
document.getElementById('quoteModal').classList.add('active');
populateSelects();
}

function closeModal(modalId) {
document.getElementById(modalId).classList.remove('active');
if (modalId === 'quoteModal') {
document.getElementById('quoteForm').reset();
}
}

// Remplissage des select
function populateSelects() {
const eventTypeSelect = document.getElementById('eventTypeSelect');
const eventSpaceSelect = document.getElementById('eventSpaceSelect');

// Remplir les types d'événements
eventTypeSelect.innerHTML = eventTypes.map(type =>
`<option value="${type.id}">${type.name} - ${type.basePrice}Fcfa</option>`
).join('');

// Remplir les espaces
eventSpaceSelect.innerHTML = eventSpaces.map(space =>
`<option value="${space.id}">${space.name} (${space.capacityMin}-${space.capacityMax} pers.)</option>`
).join('');
}

// Gestion des soumissions
function handleSubmitQuote(event) {
event.preventDefault();
const form = event.target;
const formData = new FormData(form);

const newQuote = {
id: Math.random().toString(36).substr(2, 9),
userId: 1, // À remplacer par l'ID de l'utilisateur connecté
eventTypeId: parseInt(formData.get('eventTypeId')),
eventSpaceId: parseInt(formData.get('eventSpaceId')),
expectedGuests: parseInt(formData.get('expectedGuests')),
eventDate: formData.get('eventDate'),
startTime: formData.get('startTime'),
endTime: formData.get('endTime'),
description: formData.get('description'),
specialRequirements: formData.get('specialRequirements'),
budgetRange: formData.get('budgetRange'),
status: 'pending',
createdAt: new Date(),
updatedAt: new Date(),
eventType: eventTypes.find(type => type.id === parseInt(formData.get('eventTypeId'))),
eventSpace: eventSpaces.find(space => space.id === parseInt(formData.get('eventSpaceId')))
};

eventQuotes.push(newQuote);
closeModal('quoteModal');
renderQuotes(eventQuotes);
}

// Initialisation
document.addEventListener('DOMContentLoaded', () => {
// Remplir les filtres
const eventTypeFilter = document.getElementById('filterEventType');
const spaceFilter = document.getElementById('filterSpace');

eventTypeFilter.innerHTML += eventTypes.map(type =>
`<option value="${type.id}">${type.name}</option>`
).join('');

spaceFilter.innerHTML += eventSpaces.map(space =>
`<option value="${space.id}">${space.name}</option>`
).join('');

// Afficher les demandes initiales
renderQuotes(eventQuotes);
});

// Fonction pour mettre à jour le statut d'une demande
function updateQuoteStatus(quoteId, newStatus) {
const quote = eventQuotes.find(q => q.id === quoteId);
if (quote) {
quote.status = newStatus;
quote.updatedAt = new Date();
renderQuotes(eventQuotes);
}
}

// Fonction pour vérifier la disponibilité d'un espace
function checkSpaceAvailability(spaceId, date) {
const conflictingQuotes = eventQuotes.filter(quote => 
quote.eventSpaceId === spaceId &&
quote.eventDate === date &&
quote.status !== 'cancelled'
);
return conflictingQuotes.length === 0;
}

// Fonction pour calculer le prix estimé
function calculateEstimatedPrice(eventTypeId, eventSpaceId, guestCount, duration) {
const eventType = eventTypes.find(type => type.id === eventTypeId);
const eventSpace = eventSpaces.find(space => space.id === eventSpaceId);

if (!eventType || !eventSpace) return 0;

let basePrice = eventType.basePrice + eventSpace.basePrice;
const guestFactor = Math.ceil(guestCount / 50) * 200000; // 500Fcfa par tranche de 50 invités
const durationFactor = duration * 100000; // 200Fcfa par heure

return basePrice + guestFactor + durationFactor;
}

// Créer le conteneur pour le composant React
const spacesContainer = document.getElementById('spacesGrid');

// Fonction pour gérer les espaces
function SpaceManagement() {
let spaces = [
{ id: 1, name: 'Grande Salle', capacity: 200, description: 'Salle principale pour grands événements' },
{ id: 2, name: 'Salle de Conférence', capacity: 50, description: 'Idéale pour les réunions' }
];

// Fonction pour afficher les espaces
function displaySpaces() {
const spacesHTML = spaces.map(space => `
    <div class="space-card">
        <div class="space-header">
            <h3>${space.name}</h3>
            <div class="space-actions">
                <button onclick="editSpace(${space.id})" class="edit-btn">
                    <i class="fas fa-edit"></i>
                </button>
                <button onclick="deleteSpace(${space.id})" class="delete-btn">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
        <div class="space-content">
            <p class="capacity">Capacité: ${space.capacity} personnes</p>
            <p class="description">${space.description}</p>
        </div>
    </div>
`).join('');

spacesContainer.innerHTML = `
    <div class="spaces-header">
        <button onclick="showAddSpaceModal()" class="add-space-btn">
            <i class="fas fa-plus"></i> Ajouter un Espace
        </button>
    </div>
    <div class="spaces-grid">
        ${spacesHTML}
    </div>
`;
}

// Fonction pour ajouter un espace
window.addSpace = function(event) {
event.preventDefault();
const form = event.target;
const newSpace = {
    id: spaces.length + 1,
    name: form.spaceName.value,
    capacity: parseInt(form.capacity.value),
    description: form.description.value
};
spaces.push(newSpace);
displaySpaces();
closeModal();
showAlert('Espace ajouté avec succès !');
};

// Fonction pour supprimer un espace
window.deleteSpace = function(id) {
if (confirm('Êtes-vous sûr de vouloir supprimer cet espace ?')) {
    spaces = spaces.filter(space => space.id !== id);
    displaySpaces();
    showAlert('Espace supprimé avec succès !');
}
};

// Fonction pour éditer un espace
window.editSpace = function(id) {
const space = spaces.find(s => s.id === id);
if (!space) return;

showAddSpaceModal(space);
};

// Fonction pour afficher le modal d'ajout/édition
window.showAddSpaceModal = function(space = null) {
const modalSpace = document.createElement('div');
modalSpace.className = 'modalSpace';
modalSpace.innerHTML = `
    <div class="modal-content">
        <span class="close" onclick="closeModal()">&times;</span>
        <h2>${space ? 'Modifier l\'espace' : 'Ajouter un nouvel espace'}</h2>
        <form onsubmit="${space ? 'updateSpace(event, ' + space.id + ')' : 'addSpace(event)'}">
            <div class="form-group">
                <label>Nom de l'espace</label>
                <input type="text" name="spaceName" value="${space ? space.name : ''}" required>
            </div>
            <div class="form-group">
                <label>Capacité</label>
                <input type="number" name="capacity" value="${space ? space.capacity : ''}" required>
            </div>
            <div class="form-group">
                <label>Description</label>
                <textarea name="description" required>${space ? space.description : ''}</textarea>
            </div>
            <button type="submit">${space ? 'Modifier' : 'Ajouter'}</button>
        </form>
    </div>
`;
document.body.appendChild(modalSpace);
};

// Fonction pour mettre à jour un espace
window.updateSpace = function(event, id) {
event.preventDefault();
const form = event.target;
const updatedSpace = {
    id: id,
    name: form.spaceName.value,
    capacity: parseInt(form.capacity.value),
    description: form.description.value
};
spaces = spaces.map(space => space.id === id ? updatedSpace : space);
displaySpaces();
closeModal();
showAlert('Espace modifié avec succès !');
};

// Fonction pour fermer le modal
window.closeModal = function() {
const modal = document.querySelector('.modalSpace');
if (modal) {
    modal.remove();
}
};

// Fonction pour afficher une alerte
function showAlert(message) {
const alert = document.createElement('div');
alert.className = 'alert';
alert.textContent = message;
document.body.appendChild(alert);
setTimeout(() => alert.remove(), 3000);
}

// Initialisation
displaySpaces();
}

// Initialiser la gestion des espaces quand l'onglet des espaces est actif
document.querySelector('[onclick="switchTab(\'spaces\')"]').addEventListener('click', function() {
if (!spacesContainer.initialized) {
SpaceManagement();
spacesContainer.initialized = true;
}
});
