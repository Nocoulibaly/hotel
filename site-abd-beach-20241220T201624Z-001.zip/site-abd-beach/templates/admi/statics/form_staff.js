// Données exemple
let staffData = [
    {
        id: 1,
        firstname: "Jean",
        lastname: "Dupont",
        email: "jean.dupont@hotel.com",
        phone: "0123456789",
        role: "Réceptionniste",
        status: "active",
        created_at: "2023-01-01",
        updated_at: "2023-01-01"
    },
    // Ajoutez plus de données ici
];

// Fonction pour basculer le thème
function toggleTheme() {
    document.body.classList.toggle('dark-mode');
    const icon = document.querySelector('.theme-toggle i');
    icon.classList.toggle('fa-moon');
    icon.classList.toggle('fa-sun');
}

// Fonction pour ouvrir le modal
function openModal() {
    document.getElementById('staffModal').style.display = 'flex';
}

// Fonction pour fermer le modal
function closeModal() {
    document.getElementById('staffModal').style.display = 'none';
}

// Fonction pour rendre le tableau
function renderStaffTable() {
    const tbody = document.getElementById('staffTableBody');
    tbody.innerHTML = '';

    staffData.forEach(staff => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${staff.id}</td>
            <td>${staff.lastname}</td>
            <td>${staff.firstname}</td>
            <td>${staff.email}</td>
            <td>${staff.phone}</td>
            <td>${staff.role}</td>
            <td><span class="status status-${staff.status}">${staff.status}</span></td>
            <td>
                <button class="action-btn edit-btn" onclick="editStaff(${staff.id})">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="action-btn delete-btn" onclick="deleteStaff(${staff.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

// Fonction pour éditer un employé
function editStaff(id) {
    const staff = staffData.find(s => s.id === id);
    if (staff) {
        document.getElementById('modalTitle').textContent = 'Modifier un employé';
        // Remplir le formulaire avec les données existantes
        document.getElementById('firstname').value = staff.firstname;
        document.getElementById('lastname').value = staff.lastname;
        document.getElementById('email').value = staff.email;
        document.getElementById('phone').value = staff.phone;
        document.getElementById('role').value = staff.role;
        document.getElementById('status').value = staff.status;
        openModal();
    }
}

// Fonction pour supprimer un employé
function deleteStaff(id) {
    if (confirm('Êtes-vous sûr de vouloir supprimer cet employé ?')) {
        staffData = staffData.filter(staff => staff.id !== id);
        renderStaffTable();
    }
}

// Gestionnaire de soumission du formulaire
document.getElementById('staffForm').addEventListener('submit', function(e) {
    e.preventDefault();
    // Traitement du formulaire ici
    closeModal();
});

// Initialiser le tableau
renderStaffTable();

// Fonction de recherche
document.querySelector('.search-input').addEventListener('input', function(e) {
    const searchTerm = e.target.value.toLowerCase();
    const filteredData = staffData.filter(staff => 
        staff.firstname.toLowerCase().includes(searchTerm) ||
        staff.lastname.toLowerCase().includes(searchTerm) ||
        staff.email.toLowerCase().includes(searchTerm) ||
        staff.role.toLowerCase().includes(searchTerm)
    );
    
    const tbody = document.getElementById('staffTableBody');
    tbody.innerHTML = '';
    filteredData.forEach(staff => {
        // Même logique de rendu que dans renderStaffTable
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${staff.id}</td>
            <td>${staff.lastname}</td>
            <td>${staff.firstname}</td>
            <td>${staff.email}</td>
            <td>${staff.phone}</td>
            <td>${staff.role}</td>
            <td><span class="status status-${staff.status}">${staff.status}</span></td>
            <td>
                <button class="action-btn edit-btn" onclick="editStaff(${staff.id})">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="action-btn delete-btn" onclick="deleteStaff(${staff.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        tbody.appendChild(tr);
    });
});