// database/init.go
package database

import (
	"database/sql"
	"log"

	_ "github.com/mattn/go-sqlite3"
)

func InitDB(dbPath string) *sql.DB {
	var err error
	db, err = sql.Open("sqlite3", dbPath)
	if err != nil {
		log.Fatal(err)
	}

	// Vérifier la connexion
	err = db.Ping()
	if err != nil {
		log.Fatal(err)
	}

	// Définir les paramètres de connexion
	db.SetMaxOpenConns(25)
	db.SetMaxIdleConns(25)

	log.Printf("Database connected successfully: %s", dbPath)
	return db
}

func CloseDB() {
	if db != nil {
		db.Close()
	}
}