// database/db.go
package database

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"log"
	"time"

	_ "github.com/mattn/go-sqlite3"
)

// DB wrapper pour ajouter des fonctionnalités supplémentaires
type DB struct {
	*sql.DB
}

var (
	ErrNoRows = errors.New("no rows found")
	db        *DB
)

// InitDB initialise la base de données avec des paramètres optimisés
func InitDB(filepath string) *DB {
	sqlDB, err := sql.Open("sqlite3", filepath)
	if err != nil {
		log.Fatal(err)
	}

	// Vérification de la connexion
	if err := sqlDB.Ping(); err != nil {
		fmt.Println("liliiii")
		log.Fatal(err)
	}

	// Configuration du pool de connexions
	sqlDB.SetMaxOpenConns(25)
	sqlDB.SetMaxIdleConns(5)
	sqlDB.SetConnMaxLifetime(5 * time.Minute)

	db = &DB{sqlDB}

	createTables(db.DB) // Utilise la fonction existante

	return db
}

// GetDB retourne l'instance de la base de données
func GetDB() *DB {
	return db
}

// WithTx exécute une fonction dans une transaction
func (db *DB) WithTx(ctx context.Context, fn func(*sql.Tx) error) error {
	tx, err := db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}

	defer func() {
		if p := recover(); p != nil {
			tx.Rollback()
			panic(p)
		}
	}()

	if err := fn(tx); err != nil {
		tx.Rollback()
		return err
	}

	return tx.Commit()
}

// ExecContext wrapper avec logging
func (db *DB) ExecContext(ctx context.Context, query string, args ...interface{}) (sql.Result, error) {
	return db.DB.ExecContext(ctx, query, args...)
}

// QueryContext wrapper avec logging
func (db *DB) QueryContext(ctx context.Context, query string, args ...interface{}) (*sql.Rows, error) {
	return db.DB.QueryContext(ctx, query, args...)
}

// Close ferme proprement la connexion à la base de données
func (db *DB) Close() error {
	if db.DB != nil {
		return db.DB.Close()
	}
	return nil
}

// createTables reste inchangée - gardez votre implémentation existante
// func createTables(db *sql.DB) { ... }

func createTables(db *sql.DB) {
	tables := []string{
		`CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            first_name TEXT,
            last_name TEXT,
            phone_number TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );`,

		`CREATE TABLE IF NOT EXISTS administrators (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            first_name TEXT,
            last_name TEXT,
            role TEXT NOT NULL CHECK (role IN ('admin', 'staff')),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );`,

		`CREATE TABLE IF NOT EXISTS room_types (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            price_per_night REAL NOT NULL,
            capacity INTEGER NOT NULL,
            amenities TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );`,

		`CREATE TABLE IF NOT EXISTS rooms (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            room_number TEXT NOT NULL UNIQUE,
            room_type_id INTEGER NOT NULL,
            is_available BOOLEAN DEFAULT 1,
            image TEXT,
            FOREIGN KEY (room_type_id) REFERENCES room_types(id)
        );`,

		`CREATE TABLE IF NOT EXISTS reservé (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            room_id INTEGER NOT NULL,
            check_in_date DATE NOT NULL,
            check_out_date DATE NOT NULL,
            num_adults INTEGER NOT NULL,                 -- Nombre d'adultes
            num_children INTEGER NOT NULL,                -- Nombre d'enfants
            status TEXT NOT NULL CHECK (status IN ('pending', 'confirmed', 'cancelled')),
            total_price REAL NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (room_id) REFERENCES rooms(id)
        );`,

		`CREATE TABLE IF NOT EXISTS reservations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            room_id INTEGER NOT NULL,
            check_in_date DATE NOT NULL,
            check_out_date DATE NOT NULL,
            FOREIGN KEY (room_id) REFERENCES rooms(id)
        );`,

		`CREATE TABLE IF NOT EXISTS services (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            service_name TEXT NOT NULL,
            description TEXT,
            price REAL NOT NULL,
            category TEXT NOT NULL
        );`,

		`CREATE TABLE IF NOT EXISTS reservation_services (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            reservation_id INTEGER NOT NULL,
            service_id INTEGER NOT NULL,
            quantity INTEGER NOT NULL,
            FOREIGN KEY (reservation_id) REFERENCES reservations(id),
            FOREIGN KEY (service_id) REFERENCES services(id)
        );`,

		`CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_name TEXT NOT NULL,
            description TEXT,
            event_date DATE NOT NULL,
            room_id INTEGER NOT NULL,
            capacity INTEGER NOT NULL,
            price REAL NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (room_id) REFERENCES rooms(id)
        );`,

		`CREATE TABLE IF NOT EXISTS event_bookings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            num_attendees INTEGER NOT NULL,
            status TEXT NOT NULL CHECK (status IN ('pending', 'confirmed', 'cancelled')),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (event_id) REFERENCES events(id),
            FOREIGN KEY (user_id) REFERENCES users(id)
        );`,

		`CREATE TABLE IF NOT EXISTS reviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            reservation_id INTEGER NOT NULL,
            rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
            comment TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (reservation_id) REFERENCES reservations(id)
        );`,

		`CREATE TABLE IF NOT EXISTS loyalty_points (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL UNIQUE,
            points INTEGER NOT NULL DEFAULT 0,
            last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        );`,
	}

	for _, table := range tables {
		_, err := db.Exec(table)
		if err != nil {
			log.Fatal("Failed to create table: %v", err)
		}
	}
}

// AddColumnsToReservations ajoute les colonnes num_adults et num_children à la table reservations
func AddColumnsToReservations() error {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	// Commande SQL pour ajouter les colonnes
	alterTableQuery1 := `ALTER TABLE reservations ADD COLUMN num_adults INTEGER NOT NULL DEFAULT 1;`
	alterTableQuery2 := `ALTER TABLE reservations ADD COLUMN num_children INTEGER NOT NULL DEFAULT 0;`

	// Exécution de la première requête pour num_adults
	_, err := GetDB().ExecContext(ctx, alterTableQuery1)
	if err != nil {
		log.Printf("Erreur lors de l'ajout de la colonne num_adults : %v", err)
		return err
	}

	// Exécution de la deuxième requête pour num_children
	_, err = GetDB().ExecContext(ctx, alterTableQuery2)
	if err != nil {
		log.Printf("Erreur lors de l'ajout de la colonne num_children : %v", err)
		return err
	}

	log.Println("Colonnes num_adults et num_children ajoutées avec succès.")
	return nil
}
