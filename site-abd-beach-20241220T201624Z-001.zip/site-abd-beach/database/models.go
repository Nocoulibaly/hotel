// database/models.go
package database

import (
	"database/sql"
)

// DB connection singleton
var db *sql.DB

func GetDB() *sql.DB {
	return db
}

func SetDB(database *sql.DB) {
	db = database
}
