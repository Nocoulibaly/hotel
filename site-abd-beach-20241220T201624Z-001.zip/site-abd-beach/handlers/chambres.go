// handlers/chambres.go
package handlers

import (
	"encoding/json"
	"fmt"
	"net/http"
	"site-abd-beach/database"
	"site-abd-beach/models"
	"text/template"
)

func GetChambres(w http.ResponseWriter, r *http.Request) {
	// Interagir avec la base de données
	rows, err := database.GetDB().QueryContext(r.Context(), "SELECT id, name, max_occupancy, image, Status FROM room_types")
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	defer rows.Close()

	var chambres []models.RoomType
	for rows.Next() {
		var chambre models.RoomType
		err := rows.Scan(&chambre.ID, &chambre.Image, &chambre.Description, &chambre.Status)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		chambres = append(chambres, chambre)
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(chambres)
}

func CreateChambre(w http.ResponseWriter, r *http.Request) {
	var chambre models.RoomType
	err := json.NewDecoder(r.Body).Decode(&chambre)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	// Insertion dans la base de données
	_, err = database.GetDB().ExecContext(r.Context(), "INSERT INTO room_types (name, status, description) VALUES (?, ?, ?, ?)", chambre.Image, chambre.Status, chambre.Description)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusCreated)
	json.NewEncoder(w).Encode(chambre)
}

func UpdateChambre(w http.ResponseWriter, r *http.Request) {
	var chambre models.RoomType
	err := json.NewDecoder(r.Body).Decode(&chambre)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	_, err = database.GetDB().ExecContext(r.Context(), "UPDATE room_types SET   status = ?, description = ? WHERE id = ?", chambre.Description, chambre.Status, chambre.ID)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(chambre)
}

func DeleteChambre(w http.ResponseWriter, r *http.Request) {
	id := r.URL.Query().Get("id")
	if id == "" {
		http.Error(w, "Invalid room ID", http.StatusBadRequest)
		return
	}

	_, err := database.GetDB().ExecContext(r.Context(), "DELETE FROM room_types WHERE id = ?", id)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusOK)
}

func GetRoomTypes(w http.ResponseWriter, r *http.Request) {
	db := database.GetDB()

	// Ajout d'ORDER BY pour un affichage ordonné
	query := `SELECT id, name, description, image, price_per_night, 
              max_occupancy, number_of_rooms 
              FROM room_types 
              ORDER BY price_per_night`

	rows, err := db.Query(query)
	if err != nil {
		http.Error(w, "Erreur lors de la récupération des chambres", http.StatusInternalServerError)
		return
	}
	defer rows.Close()

	var roomTypes []models.RoomType
	for rows.Next() {
		var rt models.RoomType
		if err := rows.Scan(&rt.ID, &rt.Name, &rt.Description, &rt.Image,
			&rt.PricePerNight, &rt.MaxOccupancy, &rt.NumberOfRooms); err != nil {
			http.Error(w, "Erreur lors du scan des données", http.StatusInternalServerError)
			return
		}
		roomTypes = append(roomTypes, rt)
	}

	if err = rows.Err(); err != nil {
		http.Error(w, "Erreur lors de l'itération des résultats", http.StatusInternalServerError)
		return
	}

	tmpl := template.Must(template.ParseFiles("templates/admin/rooms.html"))
	if err := tmpl.Execute(w, roomTypes); err != nil {
		fmt.Println("Erreurbd")
		http.Error(w, "Erreur lors du rendu du template", http.StatusInternalServerError)
		return
	}
}
