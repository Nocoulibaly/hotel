//handlers/user.go

package handlers

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"site-abd-beach/authentification"
	"site-abd-beach/database"
	"site-abd-beach/models"
)

// UserCredentials représente les informations d'identification de l'utilisateur
type UserCredentials struct {
	Email       string `json:"email"` // Email est maintenant requis
	Password    string `json:"password"`
	FirstName   string `json:"first_name,omitempty"`
	LastName    string `json:"last_name,omitempty"`
	PhoneNumber string `json:"phone_number,omitempty"`
	Address     string `json:"address,omitempty"`
	City        string `json:"city,omitempty"`
	Country     string `json:"country,omitempty"`
}

// UserResponse représente la réponse après connexion
type UserResponse struct {
	Message  string `json:"message"`
	UserID   int    `json:"userId"`
	UserType string `json:"userType"`
	Redirect string `json:"redirect"`
}

// RegisterHandler gère l'inscription d'un nouvel utilisateur
func RegisterHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		var creds UserCredentials
		err := json.NewDecoder(r.Body).Decode(&creds)
		if err != nil {
			http.Error(w, "Invalid request payload", http.StatusBadRequest)
			return
		}

		err = authentification.Register(creds.Password, creds.Email, creds.FirstName, creds.LastName, creds.PhoneNumber, creds.Address, creds.City, creds.Country)
		if err != nil {
			if err == authentification.ErrUserExists {
				http.Error(w, err.Error(), http.StatusConflict) // 409 Conflict
			} else {
				http.Error(w, "Internal server error", http.StatusInternalServerError)
			}
			return
		}

		w.WriteHeader(http.StatusCreated) // 201 Created
		json.NewEncoder(w).Encode("User registered successfully")
		fmt.Println("Utilisateur enregistré")
	} else {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
	}
}

// LoginHandler modifié
func LoginHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	fmt.Println("Login Request Headers:", r.Header)

	var creds UserCredentials
	if err := json.NewDecoder(r.Body).Decode(&creds); err != nil {
		http.Error(w, "Invalid request payload", http.StatusBadRequest)
		return
	}

	fmt.Printf("Login attempt - Email: %s\n", creds.Email)

	// Authentification de l'utilisateur
	userID, userType, err := authentification.Login(creds.Email, creds.Password)
	if err != nil {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusUnauthorized)
		json.NewEncoder(w).Encode(map[string]string{
			"message": "Email ou mot de passe incorrect",
		})
		return
	}
	fmt.Println(userType)

	// Création de la session avec l'ID utilisateur
	if err := authentification.SetSession(w, r, userID); err != nil {
		log.Printf("Failed to set session: %v\n", err)
		http.Error(w, "Erreur lors de la création de la session", http.StatusInternalServerError)
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusInternalServerError)
		json.NewEncoder(w).Encode(map[string]string{
			"message": "Erreur lors de la création de la session",
		})
		return
	}
	log.Printf("Response headers: %v\n", w.Header())
    log.Printf("Setting cookie for domain: localhost\n")
	log.Printf("Session set successfully for user ID %d\n", userID)

	// Renvoyer uniquement les informations nécessaires
	response := UserResponse{
		Message:  "Connexion réussie",
		UserID:   userID,
		UserType: userType,
	}

	// Réponse réussie avec l'ID de l'utilisateur
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(response)
}

func LogoutHandler(w http.ResponseWriter, r *http.Request) {
	err := authentification.ClearSession(w, r)
	if err != nil {
		http.Error(w, "Erreur lors de la déconnexion", http.StatusInternalServerError)
		return
	}
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(map[string]string{
		"message": "Déconnexion réussie",
	})
}

// HomeHandler gère la route /home
func UserHandler(w http.ResponseWriter, r *http.Request) {
	// Récupérer l'ID utilisateur depuis la session
	userID, err := authentification.GetSession(r)
	if err != nil {
		log.Printf("UserHandler: Failed to retrieve session: %v\n", err)
		http.Error(w, "Non authentifié", http.StatusUnauthorized)
		return
	}
	log.Printf("UserHandler: Fetching user information for user ID: %d\n", userID)

	// Utiliser la base de données depuis votre package
	db := database.GetDB()

	// Récupérer les informations de l'utilisateur
	user, err := GetUserByID(db, userID)
	if err != nil {
		if err == sql.ErrNoRows {
			log.Printf("UserHandler: User not found for ID: %d\n", userID)
			http.Error(w, "Utilisateur non trouvé", http.StatusNotFound)
		} else {
			log.Printf("UserHandler: Internal server error: %v\n", err)
			http.Error(w, "Erreur serveur", http.StatusInternalServerError)
		}
		return
	}
	log.Printf("UserHandler: User information fetched successfully for user ID: %d\n", userID)

	// Préparer la réponse
	response := models.User{
		ID:          userID,
		Email:       user.Email,
		FirstName:   user.FirstName,
		LastName:    user.LastName,
		PhoneNumber: user.PhoneNumber,
		Address:     user.Address,
		City:        user.City,
		Country:     user.Country,
		Status:      user.Status,
	}

	// Envoyer la réponse JSON
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}

// AuthMiddleware vérifie l'authentification
func AuthMiddleware(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		// Vérifier la validité de la session
		if !authentification.IsSessionValid(r) {
			log.Println("AuthMiddleware: Session is invalid")
			http.Error(w, "Non autorisé", http.StatusUnauthorized)
			return
		}
		// Vérifier si l'utilisateur est authentifié
		_, err := authentification.GetSession(r)
		if err != nil {
			log.Printf("AuthMiddleware: Failed to retrieve session: %v\n", err)
			http.Error(w, "Non authentifié", http.StatusUnauthorized)
			return
		}

		// Utilisateur authentifié, continuer vers le handler
		log.Println("AuthMiddleware: Session is valid, proceeding to next handler")
		next(w, r)
	}
}

// getUserByID récupère les informations de l'utilisateur depuis la base de données
func GetUserByID(db *sql.DB, userID int) (*models.User, error) {
	log.Printf("GetUserByID: Fetching user information for user ID: %d\n", userID)

	user := &models.User{}
	err := db.QueryRow(`
        SELECT username, email, first_name, last_name, phone_number, address, city, country, status  
        FROM users 
        WHERE id = ?`,
		userID).Scan(&user.Email, &user.FirstName, &user.LastName, &user.PhoneNumber, &user.Address, &user.City, &user.Country, &user.Status)
		if err != nil {
			log.Printf("GetUserByID: Failed to fetch user information: %v\n", err)
			return nil, err
		}
	
		log.Printf("GetUserByID: User information fetched successfully for user ID: %d\n", userID)
	return user, err
}
