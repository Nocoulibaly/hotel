//handlers/reservations.go
package handlers
import (
    "encoding/json"
    "net/http"
    "site-abd-beach/database"
    "site-abd-beach/models"
)

func GetReservations(w http.ResponseWriter, r *http.Request) {
    // Récupérer les réservations avec les informations de l'utilisateur et de la chambre
    query := `
        SELECT r.id, r.user_id, r.room_id, r.check_in_date, r.check_out_date, r.status, r.num_of_guests, 
               u.id AS user_id, u.first_name, u.last_name, u.email,
               rm.id AS room_id, rm.room_type, rm.price_per_night
        FROM reservations r
        JOIN users u ON r.user_id = u.id
        JOIN room_types rm ON r.room_id = rm.id
    `
    
    rows, err := database.GetDB().QueryContext(r.Context(), query)
    if err != nil {
        http.Error(w, err.Error(), http.StatusInternalServerError)
        return
    }
    defer rows.Close()

    var reservations []models.Reservation
    for rows.Next() {
        var reservation models.Reservation
        var user models.User
        var room models.RoomType

        err := rows.Scan(
            &reservation.ID, &reservation.UserID, &reservation.RoomID, &reservation.CheckInDate,
            &reservation.CheckOutDate, &reservation.Status, &reservation.NumberOfGuests, &reservation.TotalPrice,
            &user.ID, &user.FirstName, &user.LastName, &user.Email,
            &room.ID,
        )
        if err != nil {
            http.Error(w, err.Error(), http.StatusInternalServerError)
            return
        }

        // Assigner les informations de l'utilisateur et de la chambre à la réservation
        reservation.User = &user
        reservation.RoomType = &room

        reservations = append(reservations, reservation)
    }

    // Vérifier les erreurs lors de la lecture des lignes
    if err := rows.Err(); err != nil {
        http.Error(w, err.Error(), http.StatusInternalServerError)
        return
    }

    // Retourner la réponse JSON avec les réservations et les informations associées
    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(reservations)
}

func UpdateReservation(w http.ResponseWriter, r *http.Request) {
    var reservation models.Reservation
    err := json.NewDecoder(r.Body).Decode(&reservation)
    if err != nil {
        http.Error(w, err.Error(), http.StatusBadRequest)
        return
    }

    _, err = database.GetDB().ExecContext(r.Context(), "UPDATE reservations SET user_id = ?, room_id = ?, check_in = ?, check_out = ?, number_of_guests = ?, status = ? WHERE id = ?", reservation.UserID, reservation.RoomID, reservation.CheckInDate, reservation.CheckOutDate, reservation.NumberOfGuests, reservation.Status, reservation.ID)
    if err != nil {
        http.Error(w, err.Error(), http.StatusInternalServerError)
        return
    }

    w.WriteHeader(http.StatusOK)
    json.NewEncoder(w).Encode(reservation)
}

func DeleteReservation(w http.ResponseWriter, r *http.Request) {
    id := r.URL.Query().Get("id")
    if id == "" {
        http.Error(w, "Invalid reservation ID", http.StatusBadRequest)
        return
    }

    _, err := database.GetDB().ExecContext(r.Context(), "DELETE FROM reservations WHERE id = ?", id)
    if err != nil {
        http.Error(w, err.Error(), http.StatusInternalServerError)
        return
    }

    w.WriteHeader(http.StatusOK)
}

func CreateReservation(w http.ResponseWriter, r *http.Request) {
    var reservation models.Reservation
    err := json.NewDecoder(r.Body).Decode(&reservation)
    if err != nil {
        http.Error(w, err.Error(), http.StatusBadRequest)
        return
    }

    // Insérer la réservation dans la base de données
    _, err = database.GetDB().ExecContext(r.Context(), "INSERT INTO reservations (user_id, room_id, check_in, check_out, status, number_of_guests) VALUES (?, ?, ?, ?, ?, ?)", reservation.UserID, reservation.RoomID, reservation.CheckInDate, reservation.CheckOutDate, reservation.Status, reservation.NumberOfGuests)
    if err != nil {
        http.Error(w, err.Error(), http.StatusInternalServerError)
        return
    }

    w.WriteHeader(http.StatusCreated)
    json.NewEncoder(w).Encode(reservation)
}
