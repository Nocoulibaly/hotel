package handlers

import (
	"database/sql"
	"encoding/json"
	"log"
	"net/http"
	"site-abd-beach/authentification"
	//"site-abd-beach/handlers"
)

func CheckSessionHandler(db *sql.DB, w http.ResponseWriter, r *http.Request) {
	log.Println("Checking session")

	// CORS headers
	w.Header().Set("Access-Control-Allow-Origin", "http://localhost:5581")
	w.Header().Set("Access-Control-Allow-Credentials", "true")
	w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization, Set-Cookie")

	// Gérer la requête OPTIONS
	if r.Method == http.MethodOptions {
		log.Println("OPTIONS request received, responding with 200 OK")
		w.WriteHeader(http.StatusOK)
		return
	}

	// Vérification de la session
	log.Println("Validating session token")
	if authentification.IsSessionValid(r) {
		userID, err := authentification.GetSession(r)
		if err != nil {
			log.Printf("Session invalid: %v\n", err)
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusUnauthorized)
			json.NewEncoder(w).Encode(map[string]string{"error": "Session invalide"})
			return
		}

		// Récupérer les informations de l'utilisateur depuis la base de données
		user, err := GetUserByID(db, userID)
		if err != nil {
			log.Printf("Error fetching user: %v\n", err)
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusUnauthorized)
			json.NewEncoder(w).Encode(map[string]string{"error": "Utilisateur non trouvé"})
			return
		}

		log.Printf("Session valid for user ID: %d\n", userID)
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		json.NewEncoder(w).Encode(map[string]interface{}{
			"valid":  true,
			"userID": user.ID,
			"email":  user.Email,
			// Ajoutez d'autres informations utilisateur non sensibles si nécessaire
		})
	} else {
		log.Println("No session token found or token invalid")
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusUnauthorized)
		json.NewEncoder(w).Encode(map[string]string{"error": "Session invalide"})
	}
}

func CheckSessionHandlerAdapter(db *sql.DB) http.HandlerFunc {
    return func(w http.ResponseWriter, r *http.Request) {
       CheckSessionHandler(db, w, r)
    }
}