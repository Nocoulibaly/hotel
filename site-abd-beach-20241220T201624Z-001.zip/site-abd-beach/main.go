package main

import (
	"context"
	"crypto/rand"
	"database/sql"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"site-abd-beach/authentification"
	"site-abd-beach/database"
	"site-abd-beach/handlers"
	"strings"
	"syscall"
	"time"

	gorillaHandlers "github.com/gorilla/handlers" // Pour CORS
	"github.com/gorilla/mux"
)

var globalDB *sql.DB

func setupRoutes(r *mux.Router) {
	// API routes
	api := r.PathPrefix("/api").Subrouter()

	// Room routes
	api.HandleFunc("/chambres", handlers.GetChambres).Methods("GET")
	api.HandleFunc("/chambres", handlers.CreateChambre).Methods("POST")
	api.HandleFunc("/chambres/{id}", handlers.GetChambres).Methods("GET") // Corrigé: GetChambre au singulier
	api.HandleFunc("/chambres/{id}", handlers.UpdateChambre).Methods("PUT")
	api.HandleFunc("/chambres/{id}", handlers.DeleteChambre).Methods("DELETE")

	// Reservation routes
	api.HandleFunc("/reservations", handlers.GetReservations).Methods("POST")
	api.HandleFunc("/reservations", handlers.CreateReservation).Methods("POST")
	api.HandleFunc("/reservations/{id}", handlers.GetReservations).Methods("GET") // Corrigé: GetReservation au singulier
	api.HandleFunc("/reservations/{id}", handlers.UpdateReservation).Methods("PUT")
	api.HandleFunc("/reservations/{id}", handlers.DeleteReservation).Methods("DELETE")

	// Availability route
	api.HandleFunc("/availability", handlers.SearchAvailability).Methods("POST")
	//api.HandleFunc("/check-availability", handlers.SearchAvailability).Methods("POST")
	//r.HandleFunc("/disponibilite.html", handlers.DisponibiliteHTML).Methods("GET")

	// Inscription et connexion
	api.HandleFunc("/register", handlers.RegisterHandler).Methods("POST")
	api.HandleFunc("/login", handlers.LoginHandler).Methods("POST")
	api.HandleFunc("/rooms", handlers.GetRoomTypes).Methods("GET")
	api.HandleFunc("/check-session", handlers.CheckSessionHandlerAdapter(globalDB)).Methods("GET")
	api.HandleFunc("/logout", handlers.LogoutHandler).Methods("POST")

	r.HandleFunc("/login", func(w http.ResponseWriter, r *http.Request) {
		log.Println("Serving login page")
		http.ServeFile(w, r, "./templates/login.html")
	}).Methods("GET")

	// Route protégée pour la page d'accueil
	//api.HandleFunc("/user", handlers.AuthMiddleware(handlers.UserHandler)).Methods("GET")

	// Routes pour le profil utilisateur
	api.HandleFunc("/profile", handlers.GetUserProfile).Methods("GET")
	api.HandleFunc("/profile", handlers.UpdateUserProfile).Methods("PUT")

	// Nouvelle route pour la mise à jour des réservations dans le profil
	api.HandleFunc("/profile/reservations/update", handlers.UpdateUserReservation).Methods("PUT")

	// Static files
	fs := http.FileServer(http.Dir("./templates"))
	r.PathPrefix("/templates/").Handler(http.StripPrefix("/templates/", fs))

	// SPA fallback - Serve index.html for all non-API routes
	r.PathPrefix("/").HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Ne servez index.html que pour les routes GET qui ne sont pas des API
		if r.Method == "GET" && !strings.HasPrefix(r.URL.Path, "/api/") {
			http.ServeFile(w, r, "./templates/index.html")
		}
	})
}

func setupMiddleware(r *mux.Router) http.Handler {
	// CORS configuration
	corsMiddleware := gorillaHandlers.CORS(
		gorillaHandlers.AllowedOrigins([]string{"http://localhost:5581"}),
		gorillaHandlers.AllowedMethods([]string{"GET", "POST", "PUT", "DELETE", "OPTIONS"}),
		gorillaHandlers.AllowedHeaders([]string{
            "Content-Type", 
            "Authorization", 
            "X-Requested-With",
            "Accept",
            "Origin",
            "Cookie",
        }),
		gorillaHandlers.AllowCredentials(),
		gorillaHandlers.ExposedHeaders([]string{"Set-Cookie"}),
	)

	// Logging middleware
	loggingMiddleware := gorillaHandlers.LoggingHandler(os.Stdout, r)

	// Combine middlewares
	return corsMiddleware(loggingMiddleware)
}

func main() {
	// Initialize database
	db := database.InitDB("hotel.db")
	if db == nil {
		log.Fatal("Failed to initialize database")
	}
	defer db.Close()

	secretKey := make([]byte, 32)
	rand.Read(secretKey)
	authentification.InitSession(secretKey)

	// Create router
	r := mux.NewRouter()

	// Setup routes
	setupRoutes(r)

	// Apply middleware
	handler := setupMiddleware(r)

	// Create server with timeouts
	srv := &http.Server{
		Addr:         ":5581",
		Handler:      handler,
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 15 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	// Start server in goroutine
	go func() {
		fmt.Printf("Server starting on http://localhost%s\n", srv.Addr)
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("ListenAndServe(): %v", err)
		}
	}()

	// Graceful shutdown
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, os.Interrupt, syscall.SIGTERM)

	<-quit
	log.Println("Server is shutting down...")

	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()

	if err := srv.Shutdown(ctx); err != nil {
		log.Fatal("Server forced to shutdown:", err)
	}

	log.Println("Server exited gracefully")
}
