package authentification

import (
	"database/sql"
	"errors"
	"fmt"
	"site-abd-beach/models"
    "site-abd-beach/database"

	_ "github.com/mattn/go-sqlite3" // Driver SQLite
	"golang.org/x/crypto/bcrypt"
)

// ErrUserExists est retourné lorsqu'un utilisateur avec le même email existe déjà
var ErrUserExists = errors.New("user already exists")

// HashPassword crypte le mot de passe avec bcrypt
func HashPassword(password string) (string, error) {
	bytes, err := bcrypt.GenerateFromPassword([]byte(password), 14)
	return string(bytes), err
}

// CheckPasswordHash compare un mot de passe avec son hash
func CheckPasswordHash(password, hash string) bool {
	err := bcrypt.CompareHashAndPassword([]byte(hash), []byte(password))
	return err == nil
}

// Register crée un nouvel utilisateur dans la base de données.
func Register(password, email, firstName, lastName, phoneNumber, address, city, country string) error {
	if password == "" || email == "" {
		return errors.New("password and email are required")
	}

	// Hash du mot de passe avant stockage
	hashedPassword, err := HashPassword(password)
	if err != nil {
		return err
	}

	db, err := sql.Open("sqlite3", "hotel.db")
	if err != nil {
		return err
	}
	defer db.Close()

	// Vérifie si l'utilisateur existe déjà
	user, err := GetUserByEmail(db, email)
	if err != nil {
		return err
	}
	if user != nil {
		return ErrUserExists
	}

	query := `
        INSERT INTO users (
            email,
            password,
            first_name,
            last_name,
            phone_number,
            address,
            city,
            country,
            created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP);
    `

	statement, err := db.Prepare(query)
	if err != nil {
		return err
	}
	defer statement.Close()

	_, err = statement.Exec(
		email,
		hashedPassword, // Utilisation du mot de passe hashé
		firstName,
		lastName,
		phoneNumber,
		address,
		city,
		country,
	)

	return err
}

// GetUserByEmail récupère un utilisateur par son email.
func GetUserByEmail(db *sql.DB, email string) (*models.User, error) {
	query := `SELECT id, first_name, last_name, email, password, phone_number, address, city, country, status, created_at, updated_at, user_type FROM users WHERE email = ?;`

	user := &models.User{}
	err := db.QueryRow(query, email).Scan(
		&user.ID,
		&user.FirstName,
		&user.LastName,
		&user.Email,
		&user.Password,
		&user.PhoneNumber,
		&user.Address,
		&user.City,
		&user.Country,
		&user.Status,
		&user.CreatedAt,
		&user.UpdatedAt,
		&user.Usertype,
	)

	if err != nil {
		if err == sql.ErrNoRows {
			return nil, nil // Utilisateur non trouvé
		}
		return nil, err
	}
	return user, nil
}

// Login vérifie si les informations d'identification de l'utilisateur sont correctes.
func Login(email, password string) (int, string, error) {
    fmt.Printf("Login attempt started - Email: %s\n", email)
	db := database.GetDB()
	if db == nil {
        fmt.Println("ERROR: Database not initialized")
        return 0, "", errors.New("database not initialized")
    }

    fmt.Println("Database connection successful")

	fmt.Println("Attempting to get user by email:", email)
	user, err := GetUserByEmail(db, email)
	if err != nil {
        fmt.Printf("Error retrieving user: %v\n", err)
		return 0, "", err
	}

	if user == nil {
        fmt.Println("Email not found:", email)
		return 0, "", errors.New("invalid email or password")
	}

    fmt.Printf("User found - ID: %d, Email: %s, Stored Password Hash: %s\n", user.ID, user.Email, user.Password)
	// Vérification du mot de passe hashé
	passwordMatch := CheckPasswordHash(password, user.Password)
    fmt.Printf("Password check result: %v\n", passwordMatch)

    if !passwordMatch {
        fmt.Println("Password does not match for email:", email)
        return 0, "", errors.New("invalid email or password")
    }

    fmt.Printf("User authenticated successfully - ID: %d, Type: %s\n", user.ID, user.Usertype)
    return user.ID, user.Usertype, nil
}

// GetUserByIdentifier récupère un utilisateur par son email.
func GetUserByIdentifier(db *sql.DB, identifier string) (*models.User, error) {
	return GetUserByEmail(db, identifier)
}

// GetAllUsers récupère tous les utilisateurs de la base de données (si nécessaire).
func GetAllUsers(db *sql.DB) ([]models.User, error) {
	query := `SELECT id, first_name, last_name, email, password, phone_number, address, city, country, status, created_at, updated_at, user_type FROM users;`
	rows, err := db.Query(query)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var users []models.User
	for rows.Next() {
		var user models.User
		err := rows.Scan(&user.ID, &user.FirstName, &user.LastName, &user.Email, &user.Password, &user.PhoneNumber, &user.Address, &user.City, &user.Country, &user.Status, &user.CreatedAt, &user.UpdatedAt, &user.Usertype)
		if err != nil {
			return nil, err
		}
		users = append(users, user)
	}

	return users, nil
}

func GetUserTypeByID(userID int) (string, error) {
	db, err := sql.Open("sqlite", "hotel.db")
	if err != nil {
		return "", err
	}
	defer db.Close()

	var userType string
	err = db.QueryRow("SELECT user_type FROM users WHERE id = ?", userID).Scan(&userType)
	if err != nil {
		return "", err
	}

	return userType, nil
}
