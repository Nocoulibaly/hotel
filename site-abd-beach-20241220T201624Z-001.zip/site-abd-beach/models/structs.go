// models/strucs.go
package models

import "time"

/*type Room struct {
	ID          int       `json:"id" db:"id"`
	RoomNumber  string    `json:"room_number" db:"room_number"`
	CategoryID  int       `json:"category_id" db:"category_id"`
	Floor       int       `json:"floor" db:"floor"`
	Status      string    `json:"status" db:"status"`
	Description string    `json:"description" db:"description"`
	CreatedAt   time.Time `json:"created_at" db:"created_at"`
	Category    *RoomType `json:"category,omitempty"`
	RoomType    *RoomType `json:"room_type"`
}*/

// Section 2: Rooms
type RoomType struct {
	ID            int     `json:"id" db:"id"`
	Name          string  `json:"name" db:"name"`
	Description   string  `json:"description" db:"description"`
	Image         string  `json:"image" db:"image"`                     // Added to match DB
	PricePerNight float64 `json:"price_per_night" db:"price_per_night"` // Changed to match DB
	MaxOccupancy  int     `json:"max_occupancy" db:"max_occupancy"`
	Status      string    `json:"status" db:"status"`
	NumberOfRooms int     `json:"number_of_rooms"`
}

type Amenity struct {
	ID          int       `json:"id" db:"id"`
	Name        string    `json:"name" db:"name"`
	Description string    `json:"description" db:"description"`
	Icon        string    `json:"icon" db:"icon"`
	CreatedAt   time.Time `json:"created_at" db:"created_at"` // Added to match DB
}

type SeasonalRate struct {
	ID            int       `json:"id" db:"id"`
	CategoryID    int       `json:"category_id" db:"category_id"`
	StartDate     time.Time `json:"start_date" db:"start_date"`
	EndDate       time.Time `json:"end_date" db:"end_date"`
	PriceModifier float64   `json:"price_modifier" db:"price_modifier"`
}

// Section 1: Staff and Users
type HotelStaff struct {
	ID        int       `json:"id" db:"id"`
	Firstname string    `json:"firstname" db:"firstname"`
	Lastname  string    `json:"lastname" db:"lastname"`
	Email     string    `json:"email" db:"email"`
	Password  string    `json:"-" db:"password"` // Ne pas exposer dans JSON
	Role      string    `json:"role" db:"role"`
	Status    string    `json:"status" db:"status"`
	Phone     string    `json:"phone" db:"phone"`
	CreatedAt time.Time `json:"created_at" db:"created_at"`
	UpdatedAt time.Time `json:"updated_at" db:"updated_at"`
}

// Section 3: Reservations
type Reservation struct {
	ID              int       `json:"id" db:"id"`
	UserID          int       `json:"users_id" db:"users_id"` // Changed to match DB
	RoomID          int       `json:"room_id" db:"room_id"`
	CheckInDate     time.Time `json:"check_in_date" db:"check_in_date"`
	CheckOutDate    time.Time `json:"check_out_date" db:"check_out_date"`
	NumberOfGuests  int       `json:"number_of_guests" db:"number_of_guests"`
	TotalPrice      float64   `json:"total_price" db:"total_price"`
	Status          string    `json:"status" db:"status"`
	PaymentStatus   string    `json:"payment_status" db:"payment_status"`
	SpecialRequests string    `json:"special_requests" db:"special_requests"`
	CreatedAt       time.Time `json:"created_at" db:"created_at"`
	UpdatedAt       time.Time `json:"updated_at" db:"updated_at"`
	User            *User     `json:"user,omitempty"`
	//Room            *Room     `json:"room,omitempty"`
	RoomType        *RoomType `json:"room_type"`
}

type Payment struct {
	ID            int       `json:"id" db:"id"`
	ReservationID int       `json:"reservation_id" db:"reservation_id"`
	Amount        float64   `json:"amount" db:"amount"`
	PaymentMethod string    `json:"payment_method" db:"payment_method"`
	TransactionID string    `json:"transaction_id" db:"transaction_id"`
	PaymentDate   time.Time `json:"payment_date" db:"payment_date"`
	Status        string    `json:"status" db:"status"`
}

type User struct {
	ID          int       `json:"id" db:"id"`
	FirstName   string    `json:"first_name" db:"first_name"` // Changed to match DB
	LastName    string    `json:"last_name" db:"last_name"`   // Changed to match DB
	Email       string    `json:"email" db:"email"`
	Password    string    `json:"-" db:"password"`
	PhoneNumber string    `json:"phone_number" db:"phone_number"` // Changed to match DB
	Address     string    `json:"address" db:"address"`
	City        string    `json:"city" db:"city"`
	Country     string    `json:"country" db:"country"`
	Status      string    `json:"status" db:"status"`
	Usertype    string    `json:"user_type" db:"user_type"`
	CreatedAt   time.Time `json:"created_at" db:"created_at"`
	UpdatedAt   time.Time `json:"updated_at" db:"updated_at"`
}

// Section 4: Additional Services
type AdditionalService struct {
	ID          int     `json:"id" db:"id"`
	Name        string  `json:"name" db:"name"`
	Description string  `json:"description" db:"description"`
	Price       float64 `json:"price" db:"price"`
	Status      string  `json:"status" db:"status"`
}

type ReservationService struct {
	ID            int                `json:"id" db:"id"`
	ReservationID int                `json:"reservation_id" db:"reservation_id"`
	ServiceID     int                `json:"service_id" db:"service_id"`
	Quantity      int                `json:"quantity" db:"quantity"`
	Price         float64            `json:"price" db:"price"`
	Status        string             `json:"status" db:"status"`
	Service       *AdditionalService `json:"service,omitempty"`
}

// Section 5: Events
type EventType struct {
	ID          int       `json:"id" db:"id"`
	Name        string    `json:"name" db:"name"`
	Description string    `json:"description" db:"description"`
	BasePrice   float64   `json:"base_price" db:"base_price"`
	CreatedAt   time.Time `json:"created_at" db:"created_at"`
}

type EventSpace struct {
	ID           int       `json:"id" db:"id"`
	Name         string    `json:"name" db:"name"`
	Location     string    `json:"location" db:"location"`
	CapacityMin  int       `json:"capacity_min" db:"capacity_min"`
	CapacityMax  int       `json:"capacity_max" db:"capacity_max"`
	SquareMeters float64   `json:"square_meters" db:"square_meters"`
	BasePrice    float64   `json:"base_price" db:"base_price"`
	Description  string    `json:"description" db:"description"`
	Status       string    `json:"status" db:"status"`
	CreatedAt    time.Time `json:"created_at" db:"created_at"`
}

type EventQuote struct {
	ID                  int         `json:"id" db:"id"`
	UserID              int         `json:"user_id" db:"user_id"`
	EventTypeID         int         `json:"event_type_id" db:"event_type_id"`
	EventSpaceID        int         `json:"event_space_id" db:"event_space_id"`
	ExpectedGuests      int         `json:"expected_guests" db:"expected_guests"`
	EventDate           time.Time   `json:"event_date" db:"event_date"`
	StartTime           string      `json:"start_time" db:"start_time"`
	EndTime             string      `json:"end_time" db:"end_time"`
	Description         string      `json:"description" db:"description"`
	SpecialRequirements string      `json:"special_requirements" db:"special_requirements"`
	BudgetRange         string      `json:"budget_range" db:"budget_range"`
	Status              string      `json:"status" db:"status"`
	CreatedAt           time.Time   `json:"created_at" db:"created_at"`
	UpdatedAt           time.Time   `json:"updated_at" db:"updated_at"`
	User                *User       `json:"user,omitempty"`
	EventType           *EventType  `json:"event_type,omitempty"`
	EventSpace          *EventSpace `json:"event_space,omitempty"`
}

// Section 6: Maintenance and Housekeeping
type Housekeeping struct {
	ID           int         `json:"id" db:"id"`
	RoomID       int         `json:"room_id" db:"room_id"`
	StaffID      int         `json:"staff_id" db:"staff_id"`
	CleaningDate time.Time   `json:"cleaning_date" db:"cleaning_date"`
	Status       string      `json:"status" db:"status"`
	Notes        string      `json:"notes" db:"notes"`
	CreatedAt    time.Time   `json:"created_at" db:"created_at"`
	//Room         *Room       `json:"room,omitempty"`
	Staff        *HotelStaff `json:"staff,omitempty"`
}

type MaintenanceRequest struct {
	ID               int         `json:"id" db:"id"`
	RoomID           int         `json:"room_id" db:"room_id"`
	ReportedBy       int         `json:"reported_by" db:"reported_by"`
	IssueDescription string      `json:"issue_description" db:"issue_description"`
	Priority         string      `json:"priority" db:"priority"`
	Status           string      `json:"status" db:"status"`
	CreatedAt        time.Time   `json:"created_at" db:"created_at"`
	CompletedAt      time.Time   `json:"completed_at" db:"completed_at"`
	//Room             *Room       `json:"room,omitempty"`
	Reporter         *HotelStaff `json:"reporter,omitempty"`
}

// Section 7: Notifications and Logs
type Notification struct {
	ID         int       `json:"id" db:"id"`
	UserType   string    `json:"user_type" db:"user_type"`
	UserID     int       `json:"user_id" db:"user_id"`
	Title      string    `json:"title" db:"title"`
	Message    string    `json:"message" db:"message"`
	Type       string    `json:"type" db:"type"`
	ReadStatus bool      `json:"read_status" db:"read_status"`
	CreatedAt  time.Time `json:"created_at" db:"created_at"`
}

type ActivityLog struct {
	ID          int       `json:"id" db:"id"`
	UserType    string    `json:"user_type" db:"user_type"`
	UserID      int       `json:"user_id" db:"user_id"`
	Action      string    `json:"action" db:"action"`
	Description string    `json:"description" db:"description"`
	IPAddress   string    `json:"ip_address" db:"ip_address"`
	CreatedAt   time.Time `json:"created_at" db:"created_at"`
}

// Section 8: Reviews
type Review struct {
	ID            int          `json:"id" db:"id"`
	ReservationID int          `json:"reservation_id" db:"reservation_id"`
	UserID        int          `json:"user_id" db:"user_id"`
	Rating        int          `json:"rating" db:"rating"`
	Comment       string       `json:"comment" db:"comment"`
	CreatedAt     time.Time    `json:"created_at" db:"created_at"`
	Status        string       `json:"status" db:"status"`
	User          *User        `json:"user,omitempty"`
	Reservation   *Reservation `json:"reservation,omitempty"`
}
