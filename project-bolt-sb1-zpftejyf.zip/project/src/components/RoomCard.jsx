import React from 'react';
import { Link } from 'react-router-dom';

function RoomCard({ room }) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="p-6">
        <h2 className="text-xl font-semibold mb-2">{room.name}</h2>
        <p className="text-gray-600 mb-4">{room.description}</p>
        <p className="text-2xl font-bold text-indigo-600 mb-4">{room.price_per_night}€ / nuit</p>
        <div className="space-y-2">
          <h3 className="font-semibold">Équipements:</h3>
          <ul className="list-disc list-inside text-gray-600">
            {room.amenities.map((amenity, index) => (
              <li key={index}>{amenity}</li>
            ))}
          </ul>
        </div>
        <div className="mt-4">
          <Link
            to="/booking"
            className="inline-block bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700 transition-colors"
          >
            Réserver
          </Link>
        </div>
      </div>
    </div>
  );
}

export default RoomCard;