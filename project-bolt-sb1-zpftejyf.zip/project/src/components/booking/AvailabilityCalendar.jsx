import React, { useState, useEffect } from 'react';
import Calendar from 'react-calendar';
import { getAvailabilityCalendar } from '../../services/availabilityService';
import 'react-calendar/dist/Calendar.css';

function AvailabilityCalendar({ roomTypeId, onDateSelect }) {
  const [availability, setAvailability] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadAvailability();
  }, [roomTypeId]);

  const loadAvailability = async () => {
    setLoading(true);
    try {
      const date = new Date();
      const data = await getAvailabilityCalendar(
        roomTypeId,
        date.getMonth() + 1,
        date.getFullYear()
      );
      setAvailability(data);
    } catch (error) {
      console.error('Error loading availability:', error);
    } finally {
      setLoading(false);
    }
  };

  const tileDisabled = ({ date }) => {
    return !availability.some(day => 
      day.date === date.toISOString().split('T')[0] && day.available
    );
  };

  return (
    <div className="mt-4">
      {loading ? (
        <div>Chargement du calendrier...</div>
      ) : (
        <Calendar
          onChange={onDateSelect}
          tileDisabled={tileDisabled}
          minDate={new Date()}
          className="rounded-lg border p-4"
        />
      )}
    </div>
  );
}

export default AvailabilityCalendar;