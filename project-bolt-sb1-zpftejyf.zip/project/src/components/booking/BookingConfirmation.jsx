import React from 'react';
import { sendBookingConfirmation } from '../../services/emailService';

function BookingConfirmation({ booking }) {
  React.useEffect(() => {
    sendBookingConfirmation(booking).catch(console.error);
  }, [booking]);

  return (
    <div className="bg-green-50 p-6 rounded-lg">
      <h2 className="text-2xl font-bold text-green-800 mb-4">
        Réservation confirmée !
      </h2>
      <div className="space-y-4">
        <p className="text-green-700">
          Un email de confirmation a été envoyé à {booking.email}
        </p>
        <div className="border-t border-green-200 pt-4">
          <h3 className="font-semibold mb-2">Détails de la réservation:</h3>
          <ul className="space-y-2 text-green-700">
            <li>Numéro de réservation: {booking.id}</li>
            <li>Check-in: {booking.checkIn}</li>
            <li>Check-out: {booking.checkOut}</li>
            <li>Montant total: {booking.totalPrice}€</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

export default BookingConfirmation;