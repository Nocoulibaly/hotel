import React, { useState } from 'react';
import { createPaymentSession } from '../../services/stripeService';

function PaymentForm({ bookingData, onPaymentComplete }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handlePayment = async () => {
    setLoading(true);
    setError(null);

    try {
      await createPaymentSession(bookingData);
      onPaymentComplete();
    } catch (err) {
      setError('Erreur lors du paiement. Veuillez réessayer.');
      console.error('Payment error:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mt-6">
      {error && (
        <div className="mb-4 p-4 text-red-700 bg-red-100 rounded">
          {error}
        </div>
      )}
      
      <div className="bg-gray-50 p-6 rounded-lg">
        <h3 className="text-lg font-semibold mb-4">Résumé de la réservation</h3>
        <div className="space-y-2">
          <p>Prix total: {bookingData.totalPrice}€</p>
          <p>Dates: {bookingData.checkIn} - {bookingData.checkOut}</p>
        </div>
        
        <button
          onClick={handlePayment}
          disabled={loading}
          className="mt-4 w-full bg-indigo-600 text-white py-2 px-4 rounded hover:bg-indigo-700 disabled:opacity-50"
        >
          {loading ? 'Traitement...' : 'Procéder au paiement'}
        </button>
      </div>
    </div>
  );
}

export default PaymentForm;