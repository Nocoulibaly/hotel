import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { getRoomTypes } from '../services/roomService';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorMessage from '../components/ErrorMessage';

function Home() {
  const [featuredRooms, setFeaturedRooms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadFeaturedRooms();
  }, []);

  const loadFeaturedRooms = async () => {
    try {
      const rooms = await getRoomTypes();
      setFeaturedRooms(rooms.slice(0, 2)); // Afficher seulement les 2 premiers types de chambres
    } catch (err) {
      setError("Erreur lors du chargement des chambres");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} />;

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-4xl font-bold text-center mb-8">
        Bienvenue à l'Hôtel Luxe
      </h1>
      
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <p className="text-lg text-gray-700 mb-4">
          Découvrez le confort et l'élégance dans notre établissement de prestige.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h2 className="text-2xl font-semibold mb-3">Nos Services</h2>
            <ul className="list-disc list-inside text-gray-600">
              <li>Chambres luxueuses</li>
              <li>Restaurant gastronomique</li>
              <li>Spa et bien-être</li>
              <li>Service en chambre 24/7</li>
            </ul>
          </div>
          <div>
            <h2 className="text-2xl font-semibold mb-3">Contact</h2>
            <p className="text-gray-600">
              Téléphone: +123 456 789<br />
              Email: contact@hotelluxe.com<br />
              Adresse: 123 Avenue des Champs-Élysées<br />
              Paris, France
            </p>
          </div>
        </div>
      </div>

      <div className="mt-8">
        <h2 className="text-2xl font-bold mb-4">Chambres en Vedette</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {featuredRooms.map(room => (
            <div key={room.id} className="bg-white rounded-lg shadow-md p-4">
              <h3 className="text-xl font-semibold">{room.name}</h3>
              <p className="text-gray-600 mt-2">{room.description}</p>
              <p className="text-lg font-bold text-indigo-600 mt-2">
                À partir de {room.price_per_night}€ / nuit
              </p>
              <Link
                to="/rooms"
                className="inline-block mt-4 bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700 transition-colors"
              >
                Voir les détails
              </Link>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Home;