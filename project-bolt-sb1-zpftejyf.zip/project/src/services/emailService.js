import { supabase } from '../lib/supabase';

export async function sendBookingConfirmation(bookingData) {
  try {
    const { error } = await supabase.functions.invoke('send-booking-confirmation', {
      body: { bookingData }
    });

    if (error) throw error;
  } catch (error) {
    console.error('Email error:', error);
    throw error;
  }
}

export async function sendBookingReminder(bookingId) {
  try {
    const { error } = await supabase.functions.invoke('send-booking-reminder', {
      body: { bookingId }
    });

    if (error) throw error;
  } catch (error) {
    console.error('Email error:', error);
    throw error;
  }
}