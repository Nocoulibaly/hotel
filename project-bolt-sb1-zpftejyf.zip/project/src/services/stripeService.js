import { loadStripe } from '@stripe/stripe-js';
import { supabase } from '../lib/supabase';

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

export async function createPaymentSession(bookingData) {
  try {
    const { data, error } = await supabase.functions.invoke('create-payment-session', {
      body: { bookingData }
    });

    if (error) throw error;

    const stripe = await stripePromise;
    const { error: stripeError } = await stripe.redirectToCheckout({
      sessionId: data.sessionId
    });

    if (stripeError) throw stripeError;

  } catch (error) {
    console.error('Payment error:', error);
    throw error;
  }
}