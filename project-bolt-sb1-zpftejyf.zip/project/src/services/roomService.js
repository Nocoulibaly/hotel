import { supabase } from '../lib/supabase';

export async function getRoomTypes() {
  const { data, error } = await supabase
    .from('room_types')
    .select('*')
    .order('price_per_night');
    
  if (error) throw error;
  return data;
}

export async function getAvailableRooms(checkIn, checkOut, roomTypeId) {
  const { data, error } = await supabase
    .from('rooms')
    .select(`
      *,
      room_types (*)
    `)
    .eq('room_type_id', roomTypeId)
    .eq('status', 'available')
    .not('id', 'in', (
      supabase
        .from('bookings')
        .select('room_id')
        .gte('check_out_date', checkIn)
        .lte('check_in_date', checkOut)
    ));

  if (error) throw error;
  return data;
}