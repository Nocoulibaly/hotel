import { supabase } from '../lib/supabase';
import { format } from 'date-fns';

export async function checkAvailability(roomTypeId, checkIn, checkOut) {
  const { data, error } = await supabase
    .rpc('check_room_availability', {
      p_room_type_id: roomTypeId,
      p_check_in: format(new Date(checkIn), 'yyyy-MM-dd'),
      p_check_out: format(new Date(checkOut), 'yyyy-MM-dd')
    });

  if (error) throw error;
  return data;
}

export async function getAvailabilityCalendar(roomTypeId, month, year) {
  const { data, error } = await supabase
    .rpc('get_availability_calendar', {
      p_room_type_id: roomTypeId,
      p_month: month,
      p_year: year
    });

  if (error) throw error;
  return data;
}