import { supabase } from '../lib/supabase';

export async function createBooking(bookingData) {
  // Créer ou récupérer le client
  const { data: guest, error: guestError } = await supabase
    .from('guests')
    .upsert({
      first_name: bookingData.firstName,
      last_name: bookingData.lastName,
      email: bookingData.email,
      phone: bookingData.phone
    })
    .select()
    .single();

  if (guestError) throw guestError;

  // Créer la réservation
  const { data: booking, error: bookingError } = await supabase
    .from('bookings')
    .insert({
      guest_id: guest.id,
      room_id: bookingData.roomId,
      check_in_date: bookingData.checkIn,
      check_out_date: bookingData.checkOut,
      total_price: bookingData.totalPrice,
      status: 'confirmed'
    })
    .select()
    .single();

  if (bookingError) throw bookingError;

  return booking;
}