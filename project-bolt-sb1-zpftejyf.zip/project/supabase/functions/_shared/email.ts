import { SendGridClient } from 'https://deno.land/x/sendgrid@0.0.3/mod.ts'

const sendgrid = new SendGridClient(Deno.env.get('SENDGRID_API_KEY') ?? '')

export async function sendEmail({ to, subject, html }) {
  const msg = {
    to,
    from: 'reservations@hotelluxe.com',
    subject,
    html,
  }

  try {
    await sendgrid.send(msg)
  } catch (error) {
    console.error('SendGrid error:', error)
    throw error
  }
}