import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.7'
import { sendEmail } from '../_shared/email.ts'

serve(async (req) => {
  try {
    const { bookingData } = await req.json()
    
    // Envoyer l'email
    await sendEmail({
      to: bookingData.email,
      subject: 'Confirmation de votre réservation',
      html: `
        <h1>Confirmation de réservation</h1>
        <p>Votre réservation a été confirmée !</p>
        <ul>
          <li>Check-in: ${bookingData.checkIn}</li>
          <li>Check-out: ${bookingData.checkOut}</li>
          <li>Montant total: ${bookingData.totalPrice}€</li>
        </ul>
      `
    })

    // Créer une notification
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    await supabase
      .from('notifications')
      .insert({
        user_id: bookingData.userId,
        type: 'booking_confirmation',
        content: `Votre réservation du ${bookingData.checkIn} au ${bookingData.checkOut} a été confirmée.`
      })

    return new Response(
      JSON.stringify({ success: true }),
      { status: 200 }
    )
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 400 }
    )
  }
})