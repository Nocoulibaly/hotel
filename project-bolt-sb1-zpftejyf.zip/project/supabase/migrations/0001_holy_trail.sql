/*
  # Schéma de base de données pour l'hôtel

  1. Nouvelles Tables
    - `room_types`
      - Types de chambres disponibles (Standard, Junior Suite, Suite Présidentielle)
    - `rooms`
      - Chambres individuelles avec numéros et références au type
    - `bookings`
      - Réservations des chambres
    - `guests`
      - Informations des clients

  2. Sécurité
    - RLS activé sur toutes les tables
    - Politiques de lecture publique pour room_types et rooms
    - Politiques de réservation pour utilisateurs authentifiés
*/

-- Types de chambres
CREATE TABLE room_types (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  price_per_night decimal NOT NULL,
  max_occupancy int NOT NULL,
  amenities text[] DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- Chambres individuelles
CREATE TABLE rooms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_number text NOT NULL UNIQUE,
  room_type_id uuid REFERENCES room_types(id) NOT NULL,
  floor int NOT NULL,
  status text DEFAULT 'available',
  created_at timestamptz DEFAULT now()
);

-- Clients
CREATE TABLE guests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  first_name text NOT NULL,
  last_name text NOT NULL,
  email text UNIQUE NOT NULL,
  phone text,
  created_at timestamptz DEFAULT now()
);

-- Réservations
CREATE TABLE bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  guest_id uuid REFERENCES guests(id) NOT NULL,
  room_id uuid REFERENCES rooms(id) NOT NULL,
  check_in_date date NOT NULL,
  check_out_date date NOT NULL,
  total_price decimal NOT NULL,
  status text DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  CONSTRAINT valid_dates CHECK (check_out_date > check_in_date)
);

-- Sécurité et politiques
ALTER TABLE room_types ENABLE ROW LEVEL SECURITY;
ALTER TABLE rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE guests ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;

-- Politiques de lecture publique
CREATE POLICY "Lecture publique des types de chambres"
  ON room_types FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Lecture publique des chambres"
  ON rooms FOR SELECT
  TO public
  USING (true);

-- Politiques pour les réservations
CREATE POLICY "Les clients peuvent voir leurs réservations"
  ON bookings FOR SELECT
  TO authenticated
  USING (guest_id IN (
    SELECT id FROM guests WHERE email = auth.email()
  ));

CREATE POLICY "Les clients peuvent créer des réservations"
  ON bookings FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Données initiales pour les types de chambres
INSERT INTO room_types (name, description, price_per_night, max_occupancy, amenities) VALUES
  ('Chambre Standard', 'Chambre confortable avec vue sur la ville', 100, 2, ARRAY['WiFi', 'TV', 'Climatisation', 'Mini-bar']),
  ('Suite Junior', 'Suite spacieuse avec salon séparé', 200, 3, ARRAY['WiFi', 'TV', 'Climatisation', 'Mini-bar', 'Balcon']),
  ('Suite Présidentielle', 'Notre meilleure suite avec vue panoramique', 500, 4, ARRAY['WiFi', 'TV', 'Climatisation', 'Mini-bar', 'Jacuzzi', 'Service de majordome']);

-- Création des chambres pour chaque type
DO $$
BEGIN
  -- Chambres Standard (10 chambres, étages 1-2)
  FOR i IN 1..10 LOOP
    INSERT INTO rooms (room_number, room_type_id, floor)
    SELECT 
      CASE 
        WHEN i <= 5 THEN '1' || LPAD(i::text, 2, '0')
        ELSE '2' || LPAD((i-5)::text, 2, '0')
      END,
      id,
      CASE 
        WHEN i <= 5 THEN 1
        ELSE 2
      END
    FROM room_types WHERE name = 'Chambre Standard';
  END LOOP;

  -- Suites Junior (6 chambres, étages 3-4)
  FOR i IN 1..6 LOOP
    INSERT INTO rooms (room_number, room_type_id, floor)
    SELECT 
      CASE 
        WHEN i <= 3 THEN '3' || LPAD(i::text, 2, '0')
        ELSE '4' || LPAD((i-3)::text, 2, '0')
      END,
      id,
      CASE 
        WHEN i <= 3 THEN 3
        ELSE 4
      END
    FROM room_types WHERE name = 'Suite Junior';
  END LOOP;

  -- Suites Présidentielles (2 chambres, étage 5)
  FOR i IN 1..2 LOOP
    INSERT INTO rooms (room_number, room_type_id, floor)
    SELECT '5' || LPAD(i::text, 2, '0'), id, 5
    FROM room_types WHERE name = 'Suite Présidentielle';
  END LOOP;
END $$;