/*
  # Ajout des tables pour les paiements et notifications

  1. Nouvelles Tables
    - `payments`
      - `id` (uuid, primary key)
      - `booking_id` (uuid, référence vers bookings)
      - `amount` (decimal)
      - `status` (text)
      - `stripe_session_id` (text)
      - `created_at` (timestamp)
    
    - `notifications`
      - `id` (uuid, primary key)
      - `user_id` (uuid, référence vers auth.users)
      - `type` (text)
      - `content` (text)
      - `read` (boolean)
      - `created_at` (timestamp)

  2. Sécurité
    - Enable RLS sur les nouvelles tables
    - Politiques pour les paiements et notifications
*/

-- Table des paiements
CREATE TABLE payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id uuid REFERENCES bookings(id) NOT NULL,
  amount decimal NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  stripe_session_id text,
  created_at timestamptz DEFAULT now()
);

-- Table des notifications
CREATE TABLE notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  type text NOT NULL,
  content text NOT NULL,
  read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Sécurité
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- Politiques pour les paiements
CREATE POLICY "Les utilisateurs peuvent voir leurs paiements"
  ON payments FOR SELECT
  TO authenticated
  USING (
    booking_id IN (
      SELECT b.id FROM bookings b
      JOIN guests g ON b.guest_id = g.id
      WHERE g.email = auth.email()
    )
  );

-- Politiques pour les notifications
CREATE POLICY "Les utilisateurs peuvent voir leurs notifications"
  ON notifications FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Les utilisateurs peuvent marquer leurs notifications comme lues"
  ON notifications FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());